# jsf-primefaces-jetty

A detailed step-by-step tutorial in which we build and run a Hello World PrimeFaces example using Jetty and Maven.

[https://www.codenotfound.com/jsf-primefaces-hello-world-example-jetty-maven.html](https://www.codenotfound.com/jsf-primefaces-hello-world-example-jetty-maven.html)
