# jsf-primefaces-datatable

A detailed step-by-step tutorial on how to implement a PrimeFaces DataTable using Spring Data JPA, Spring Boot, and Maven.

[https://codenotfound.com/jsf-primefaces-datatable-example.html](https://codenotfound.com/jsf-primefaces-datatable-example.html)
