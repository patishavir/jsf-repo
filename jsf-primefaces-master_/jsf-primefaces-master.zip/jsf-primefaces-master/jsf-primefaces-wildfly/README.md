# jsf-primefaces-wildfly

A detailed step-by-step tutorial in which we build and run a Hello World PrimeFaces example using WildFly and Maven.

[https://www.codenotfound.com/jsf-primefaces-hello-world-example-wildfly-maven.html](https://www.codenotfound.com/jsf-primefaces-hello-world-example-wildfly-maven.html)
