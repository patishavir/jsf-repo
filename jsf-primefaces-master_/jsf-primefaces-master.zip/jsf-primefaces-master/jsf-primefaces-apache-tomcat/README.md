# jsf-primefaces-apache-tomcat

A detailed step-by-step tutorial in which we build and run a Hello World PrimeFaces example using Apache Tomcat and Maven.

[https://www.codenotfound.com/jsf-primefaces-hello-world-example-apache-tomcat.html](https://www.codenotfound.com/jsf-primefaces-hello-world-example-apache-tomcat.html)
