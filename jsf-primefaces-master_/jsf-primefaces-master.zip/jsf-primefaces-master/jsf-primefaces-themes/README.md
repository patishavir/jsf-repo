# jsf-primefaces-themes

A code sample on how to configure the Primefaces Bootstrap theme using Spring Boot.

[https://codenotfound.com/jsf-primefaces-themes-example.html](https://codenotfound.com/jsf-primefaces-themes-example.html)
