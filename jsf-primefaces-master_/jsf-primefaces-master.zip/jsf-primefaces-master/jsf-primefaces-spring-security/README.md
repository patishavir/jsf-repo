# jsf-primefaces-spring-security

A detailed step-by-step tutorial on how to implement a PrimeFaces login page using Spring Security, Spring Boot, and Maven.

[https://codenotfound.com/jsf-primefaces-spring-security-example.html](https://codenotfound.com/jsf-primefaces-spring-security-example.html)
