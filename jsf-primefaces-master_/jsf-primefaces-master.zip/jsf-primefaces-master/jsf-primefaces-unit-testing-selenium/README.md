# jsf-primefaces-unit-testing-selenium

[![Sonarcloud Status](https://sonarcloud.io/api/project_badges/measure?project=com.codenotfound%3Ajsf-primefaces-unit-testing-selenium&metric=alert_status)](https://sonarcloud.io/dashboard?id=com.codenotfound%3Ajsf-primefaces-unit-testing-selenium)

A detailed step-by-step tutorial on how to implement an automated unit test for PrimeFaces using Selenium.

[https://codenotfound.com/jsf-primefaces-automated-unit-testing-selenium.html](https://codenotfound.com/jsf-primefaces-automated-unit-testing-selenium.html)
