# jsf-primefaces-datatable-mysql

A detailed step-by-step tutorial on how to implement a PrimeFaces DataTable using MySQL, Spring Data JPA, Spring Boot, and Maven.

[https://www.codenotfound.com/jsf-primefaces/](https://www.codenotfound.com/jsf-primefaces/)
