# JSF Primefaces Tutorials

[![Build Status](https://travis-ci.org/code-not-found/jsf-primefaces.svg?branch=master)](https://travis-ci.org/code-not-found/jsf-primefaces)
[![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)

This repository contains all the source code for the JSF Primefaces examples posted on [https://codenotfound.com/jsf-primefaces-tutorials](https://codenotfound.com/jsf-primefaces-tutorials)

In case of questions or remarks please leave a comment in the respective blog post or open a GitHub issue. Thanks!
