# jsf-primefaces-welcome-page-redirect

[![Sonarcloud Status](https://sonarcloud.io/api/project_badges/measure?project=com.codenotfound%3Ajsf-primefaces-welcome-page-redirect&metric=alert_status)](https://sonarcloud.io/dashboard?id=com.codenotfound%3Ajsf-primefaces-welcome-page-redirect)

A code sample on how to implement a PrimeFaces for JSF welcome page redirect using Spring Boot.

[https://codenotfound.com/jsf-primefaces-welcome-page-redirect-example.html](https://codenotfound.com/jsf-primefaces-welcome-page-redirect-example.html)
