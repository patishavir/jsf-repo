/*    */ package WEB-INF.classes.org.primefaces.showcase.view.menu;
/*    */ 
/*    */ import javax.faces.bean.ManagedBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ManagedBean
/*    */ public class MegaMenuView
/*    */ {
/* 23 */   private String orientation = "horizontal";
/*    */   
/*    */   public String getOrientation() {
/* 26 */     return this.orientation;
/*    */   }
/*    */   
/*    */   public void setOrientation(String orientation) {
/* 30 */     this.orientation = orientation;
/*    */   }
/*    */ }


/* Location:              D:\oj\j\primefaces\showcase-6.2.war!\WEB-INF\classes\org\primefaces\showcase\view\menu\MegaMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */