/*    */ package WEB-INF.classes.org.primefaces.showcase.view.ajax;
/*    */ 
/*    */ import javax.faces.bean.ManagedBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ManagedBean
/*    */ public class SearchView
/*    */ {
/*    */   private String text1;
/*    */   private String text2;
/*    */   
/*    */   public String getText1() {
/* 27 */     return this.text1;
/*    */   }
/*    */   
/*    */   public void setText1(String text1) {
/* 31 */     this.text1 = text1;
/*    */   }
/*    */   
/*    */   public String getText2() {
/* 35 */     return this.text2;
/*    */   }
/*    */   
/*    */   public void setText2(String text2) {
/* 39 */     this.text2 = text2;
/*    */   }
/*    */ }


/* Location:              D:\oj\j\primefaces\showcase-6.2.war!\WEB-INF\classes\org\primefaces\showcase\view\ajax\SearchView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */