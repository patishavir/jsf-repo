/*    */ package WEB-INF.classes.org.primefaces.showcase.view.ajax;
/*    */ 
/*    */ import javax.faces.bean.ManagedBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ManagedBean
/*    */ public class SelectorView
/*    */ {
/*    */   private String text1;
/*    */   private String text2;
/*    */   private String text3;
/*    */   
/*    */   public String getText1() {
/* 28 */     return this.text1;
/*    */   }
/*    */   
/*    */   public void setText1(String text1) {
/* 32 */     this.text1 = text1;
/*    */   }
/*    */   
/*    */   public String getText2() {
/* 36 */     return this.text2;
/*    */   }
/*    */   
/*    */   public void setText2(String text2) {
/* 40 */     this.text2 = text2;
/*    */   }
/*    */   
/*    */   public String getText3() {
/* 44 */     return this.text3;
/*    */   }
/*    */   
/*    */   public void setText3(String text3) {
/* 48 */     this.text3 = text3;
/*    */   }
/*    */ }


/* Location:              D:\oj\j\primefaces\showcase-6.2.war!\WEB-INF\classes\org\primefaces\showcase\view\ajax\SelectorView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */