/*    */ package WEB-INF.classes.org.primefaces.showcase.view.ajax;
/*    */ 
/*    */ import javax.faces.bean.ManagedBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ManagedBean
/*    */ public class BasicView
/*    */ {
/*    */   private String text;
/*    */   
/*    */   public String getText() {
/* 26 */     return this.text;
/*    */   }
/*    */   public void setText(String text) {
/* 29 */     this.text = text;
/*    */   }
/*    */ }


/* Location:              D:\oj\j\primefaces\showcase-6.2.war!\WEB-INF\classes\org\primefaces\showcase\view\ajax\BasicView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */