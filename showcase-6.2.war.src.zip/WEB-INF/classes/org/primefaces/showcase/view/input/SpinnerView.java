/*    */ package WEB-INF.classes.org.primefaces.showcase.view.input;
/*    */ 
/*    */ import javax.faces.bean.ManagedBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ManagedBean
/*    */ public class SpinnerView
/*    */ {
/*    */   private int number1;
/*    */   private double number2;
/*    */   private int number3;
/*    */   private int number4;
/*    */   private int number5;
/*    */   
/*    */   public int getNumber1() {
/* 30 */     return this.number1;
/*    */   }
/*    */   
/*    */   public void setNumber1(int number1) {
/* 34 */     this.number1 = number1;
/*    */   }
/*    */   
/*    */   public double getNumber2() {
/* 38 */     return this.number2;
/*    */   }
/*    */   
/*    */   public void setNumber2(double number2) {
/* 42 */     this.number2 = number2;
/*    */   }
/*    */   
/*    */   public int getNumber3() {
/* 46 */     return this.number3;
/*    */   }
/*    */   
/*    */   public void setNumber3(int number3) {
/* 50 */     this.number3 = number3;
/*    */   }
/*    */   
/*    */   public int getNumber4() {
/* 54 */     return this.number4;
/*    */   }
/*    */   
/*    */   public void setNumber4(int number4) {
/* 58 */     this.number4 = number4;
/*    */   }
/*    */   
/*    */   public int getNumber5() {
/* 62 */     return this.number5;
/*    */   }
/*    */   
/*    */   public void setNumber5(int number5) {
/* 66 */     this.number5 = number5;
/*    */   }
/*    */ }


/* Location:              D:\oj\j\primefaces\showcase-6.2.war!\WEB-INF\classes\org\primefaces\showcase\view\input\SpinnerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */