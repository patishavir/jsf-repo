/*    */ package WEB-INF.classes.org.primefaces.showcase.view.input;
/*    */ 
/*    */ import javax.faces.bean.ManagedBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ManagedBean
/*    */ public class SignatureView
/*    */ {
/*    */   private String value;
/*    */   
/*    */   public String getValue() {
/* 26 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 30 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              D:\oj\j\primefaces\showcase-6.2.war!\WEB-INF\classes\org\primefaces\showcase\view\input\SignatureView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */