/*    */ package WEB-INF.classes.org.primefaces.showcase.view.input;
/*    */ 
/*    */ import javax.faces.bean.ManagedBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ManagedBean
/*    */ public class PasswordView
/*    */ {
/*    */   private String password1;
/*    */   private String password2;
/*    */   private String password3;
/*    */   private String password4;
/*    */   private String password5;
/*    */   
/*    */   public String getPassword1() {
/* 30 */     return this.password1;
/*    */   }
/*    */   
/*    */   public void setPassword1(String password1) {
/* 34 */     this.password1 = password1;
/*    */   }
/*    */   
/*    */   public String getPassword2() {
/* 38 */     return this.password2;
/*    */   }
/*    */   
/*    */   public void setPassword2(String password2) {
/* 42 */     this.password2 = password2;
/*    */   }
/*    */   
/*    */   public String getPassword3() {
/* 46 */     return this.password3;
/*    */   }
/*    */   
/*    */   public void setPassword3(String password3) {
/* 50 */     this.password3 = password3;
/*    */   }
/*    */   
/*    */   public String getPassword4() {
/* 54 */     return this.password4;
/*    */   }
/*    */   
/*    */   public void setPassword4(String password4) {
/* 58 */     this.password4 = password4;
/*    */   }
/*    */   
/*    */   public String getPassword5() {
/* 62 */     return this.password5;
/*    */   }
/*    */   
/*    */   public void setPassword5(String password5) {
/* 66 */     this.password5 = password5;
/*    */   }
/*    */ }


/* Location:              D:\oj\j\primefaces\showcase-6.2.war!\WEB-INF\classes\org\primefaces\showcase\view\input\PasswordView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */