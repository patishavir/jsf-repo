/*     */ package WEB-INF.classes.org.primefaces.showcase.view.input;
/*     */ 
/*     */ import javax.faces.bean.ManagedBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ManagedBean
/*     */ public class KeyboardView
/*     */ {
/*     */   private String value1;
/*     */   private String value2;
/*     */   private String value3;
/*     */   private String value4;
/*     */   private String value5;
/*     */   private String value6;
/*     */   private String value7;
/*     */   private String value8;
/*     */   private String value9;
/*     */   
/*     */   public String getValue1() {
/*  34 */     return this.value1;
/*     */   }
/*     */   
/*     */   public void setValue1(String value1) {
/*  38 */     this.value1 = value1;
/*     */   }
/*     */   
/*     */   public String getValue2() {
/*  42 */     return this.value2;
/*     */   }
/*     */   
/*     */   public void setValue2(String value2) {
/*  46 */     this.value2 = value2;
/*     */   }
/*     */   
/*     */   public String getValue3() {
/*  50 */     return this.value3;
/*     */   }
/*     */   
/*     */   public void setValue3(String value3) {
/*  54 */     this.value3 = value3;
/*     */   }
/*     */   
/*     */   public String getValue4() {
/*  58 */     return this.value4;
/*     */   }
/*     */   
/*     */   public void setValue4(String value4) {
/*  62 */     this.value4 = value4;
/*     */   }
/*     */   
/*     */   public String getValue5() {
/*  66 */     return this.value5;
/*     */   }
/*     */   
/*     */   public void setValue5(String value5) {
/*  70 */     this.value5 = value5;
/*     */   }
/*     */   
/*     */   public String getValue6() {
/*  74 */     return this.value6;
/*     */   }
/*     */   
/*     */   public void setValue6(String value6) {
/*  78 */     this.value6 = value6;
/*     */   }
/*     */   
/*     */   public String getValue7() {
/*  82 */     return this.value7;
/*     */   }
/*     */   
/*     */   public void setValue7(String value7) {
/*  86 */     this.value7 = value7;
/*     */   }
/*     */   
/*     */   public String getValue8() {
/*  90 */     return this.value8;
/*     */   }
/*     */   
/*     */   public void setValue8(String value8) {
/*  94 */     this.value8 = value8;
/*     */   }
/*     */   
/*     */   public String getValue9() {
/*  98 */     return this.value9;
/*     */   }
/*     */   
/*     */   public void setValue9(String value9) {
/* 102 */     this.value9 = value9;
/*     */   }
/*     */ }


/* Location:              D:\oj\j\primefaces\showcase-6.2.war!\WEB-INF\classes\org\primefaces\showcase\view\input\KeyboardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */