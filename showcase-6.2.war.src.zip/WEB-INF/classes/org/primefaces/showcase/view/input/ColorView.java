/*    */ package WEB-INF.classes.org.primefaces.showcase.view.input;
/*    */ 
/*    */ import javax.faces.bean.ManagedBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ManagedBean
/*    */ public class ColorView
/*    */ {
/*    */   private String colorInline;
/*    */   private String colorPopup;
/*    */   
/*    */   public String getColorInline() {
/* 28 */     return this.colorInline;
/*    */   }
/*    */   
/*    */   public void setColorInline(String colorInline) {
/* 32 */     this.colorInline = colorInline;
/*    */   }
/*    */   
/*    */   public String getColorPopup() {
/* 36 */     return this.colorPopup;
/*    */   }
/*    */   
/*    */   public void setColorPopup(String colorPopup) {
/* 40 */     this.colorPopup = colorPopup;
/*    */   }
/*    */ }


/* Location:              D:\oj\j\primefaces\showcase-6.2.war!\WEB-INF\classes\org\primefaces\showcase\view\input\ColorView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */